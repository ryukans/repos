#include "procedure.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    ipc shm, sem;
    pid_t pid;

    shm.key = ftok(PATHNAME, SHMID);
    shm.id = shmget(shm.key, sizeof(buffer), IPC_CREAT | 0664);
    buffer* buf = (buffer*)shmat(shm.id, NULL, 0);
    
    buf->mess.val1 = buf->mess.val2 = DEFAULT;
    buf->readers= 0;

    sem.key = ftok(PATHNAME, SEMID);
    sem.id = semget(sem.key, NSEMS, IPC_CREAT | 0664);
    semctl(sem.id, MUTEXL, SETVAL, 1);
    semctl(sem.id, SYNCHRW, SETVAL, 0);

    for(int i = 0; i < 10; i++){
        pid = fork();

        switch (pid){
        case 0:
            if(i%2)
                execl(".writer", ".writer", NULL);
            else
                execl(".readers", ".readers", NULL);
            break;
        case -1:
            perror("Error fork()\n");
            exit(-1);
            break;
        }    
    }
    
    for(int i = 0; i < 10; i++)
        wait(NULL);
    

    return 0;
}